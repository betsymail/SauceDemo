package com.SauceDemo.constants;

public class AutomationConstants {

	public static final String HOMEPAGETITLE = "Swag Labs";
	public static final String BACKPACK = "Sauce Labs Backpack";
	public static final String ONESIE = "Sauce Labs Onesie";
	public static final String JACKET = "Sauce Labs Fleece Jacket";

}
